import React from 'react';
import PropTypes from 'prop-types';
import BpkText from 'bpk-component-text';

import STYLES from './${component}.scss';

const ${component} = ({ content }) => (
  <div className={STYLES.${component}} >
    <BpkText >{content}</BpkText>
  </div>
);

${component}.propTypes = {
  content: PropTypes.string.isRequired,
};

export default ${component};
